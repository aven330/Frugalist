# Frugalist

A Pen created on CodePen.

Original URL: [https://codepen.io/akvenkat/pen/LEGWZRM](https://codepen.io/akvenkat/pen/LEGWZRM).

